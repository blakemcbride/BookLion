package booklion.client.login;

import com.google.gwt.event.logical.shared.SelectionEvent;
import com.google.gwt.event.logical.shared.SelectionHandler;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.Widget;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.widget.core.client.FramedPanel;
import com.sencha.gxt.widget.core.client.container.BoxLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VBoxLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.container.Viewport;
import com.sencha.gxt.widget.core.client.menu.*;

/**
 * @author Blake McBride ( blake@mcbride.name )
 * Date: 10/1/13
 */
public class Bug {
    private static final String userMaint = "userMaint";
    private VBoxLayoutContainer dataPanel;
    private Viewport vp;


    public void onModuleLoad() {
        RootPanel rootPanel = RootPanel.get();
        rootPanel.clear();
        vp = new Viewport();
        rootPanel.add(vp, 0, 0);

        VBoxLayoutContainer comp = new VBoxLayoutContainer();
        comp.setVBoxLayoutAlign(VBoxLayoutContainer.VBoxLayoutAlign.STRETCH);

        comp.add(makeMenu(), new BoxLayoutContainer.BoxLayoutData(new Margins(5, 5, 5, 5)));

        VBoxLayoutContainer vlc = new VBoxLayoutContainer();
        dataPanel = vlc;
        vlc.setVBoxLayoutAlign(VBoxLayoutContainer.VBoxLayoutAlign.STRETCH);
        comp.add(vlc, new BoxLayoutContainer.BoxLayoutData(new Margins(5, 5, 5, 5)));

        vp.add(comp);
    }

    private MenuBar makeMenu()  {
        Menu menu;
        MenuBar bar = new MenuBar();
        LocalSelectionHandler handler = new LocalSelectionHandler();

        bar.setBorders(false);

        // ///////////////
        menu = new Menu();
        bar.add(new MenuBarItem("File", menu));

        MenuItem mi = new MenuItem("Grid");
        mi.addSelectionHandler(handler);
        mi.setItemId(userMaint);
        menu.add(mi);

        return bar;
    }

    private void addGrid() {
        FramedPanel cp = new FramedPanel();

        VBoxLayoutContainer con = new VBoxLayoutContainer();
        con.setBorders(true);
        con.setVBoxLayoutAlign(VBoxLayoutContainer.VBoxLayoutAlign.STRETCH);

        Widget grid = new MakeGrid().asWidget();

        con.add(grid);

        con.add(new Label("Bottom of grid"));

        cp.setWidget(con);

        dataPanel.add(cp);

        vp.forceLayout();
    }

    private class LocalSelectionHandler implements SelectionHandler<Item> {

        @Override
        public void onSelection(SelectionEvent<Item> event) {
            MenuItem item = (MenuItem) event.getSelectedItem();
            String selection = item.getItemId();
            if (selection == userMaint)
                addGrid();
        }
    }
}
