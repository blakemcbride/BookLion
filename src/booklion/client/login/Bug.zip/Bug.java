package booklion.client.login;

import com.google.gwt.event.logical.shared.SelectionEvent;
import com.google.gwt.event.logical.shared.SelectionHandler;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.Widget;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.widget.core.client.FramedPanel;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.container.Viewport;
import com.sencha.gxt.widget.core.client.menu.*;

/**
 * @author Blake McBride ( blake@mcbride.name )
 * Date: 10/1/13
 */
public class Bug {
    private static final String userMaint = "userMaint";
    private VerticalLayoutContainer dataPanel;

    public void onModuleLoad() {
        RootPanel rootPanel = RootPanel.get();
        rootPanel.clear();
        Viewport vp = new Viewport();
        rootPanel.add(vp, 0, 0);

        VerticalLayoutContainer comp = new VerticalLayoutContainer();

        comp.add(makeMenu(), new VerticalLayoutContainer.VerticalLayoutData(1, -1, new Margins(5, 5, 5, 5)));

        VerticalLayoutContainer vlc = new VerticalLayoutContainer();
        dataPanel = vlc;
        comp.add(vlc, new VerticalLayoutContainer.VerticalLayoutData(1, 1, new Margins(5, 5, 5, 5)));

        vp.add(comp);

        /* Uncommenting out the following line causes the exact same functionality but without
         * requiring a user to click the menu option.  The initial size problem disappears.
         */
 //       addGrid();
    }

    private MenuBar makeMenu()  {
        Menu menu;
        MenuBar bar = new MenuBar();
        LocalSelectionHandler handler = new LocalSelectionHandler();

        bar.setBorders(false);

        // ///////////////
        menu = new Menu();
        bar.add(new MenuBarItem("File", menu));

        MenuItem mi = new MenuItem("Grid");
        mi.addSelectionHandler(handler);
        mi.setItemId(userMaint);
        menu.add(mi);

        return bar;
    }

    private void addGrid() {
        FramedPanel cp = new FramedPanel();

        VerticalLayoutContainer con = new VerticalLayoutContainer();
        con.setBorders(true);

        Widget grid = new MakeGrid().asWidget();

        con.add(grid, new VerticalLayoutContainer.VerticalLayoutData(1, 1));

        con.add(new Label("Bottom of grid"));

        cp.setWidget(con);

        dataPanel.add(cp, new VerticalLayoutContainer.VerticalLayoutData(1, 1));
    }

    private class LocalSelectionHandler implements SelectionHandler<Item> {

        @Override
        public void onSelection(SelectionEvent<Item> event) {
            MenuItem item = (MenuItem) event.getSelectedItem();
            String selection = item.getItemId();
            if (selection == userMaint)
                addGrid();
        }
    }
}
